﻿CREATE TABLE [dbo].[Tbl_Student] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [St_Name]    NVARCHAR (50) NULL,
    [St_FName]   NVARCHAR (50) NULL,
    [St_Address] NVARCHAR (50) NULL,
    [St_Doc]     NVARCHAR (50) NULL,
    [Reg_no]     VARCHAR (15)  NULL,
    CONSTRAINT [PK_Tbl_Student] PRIMARY KEY CLUSTERED ([Id] ASC)
);

