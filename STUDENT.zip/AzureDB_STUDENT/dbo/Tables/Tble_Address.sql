﻿CREATE TABLE [dbo].[Tble_Address] (
    [Id]       INT            NOT NULL,
    [HouseNo]  NVARCHAR (MAX) NULL,
    [StreetNO] NVARCHAR (MAX) NULL,
    [City]     NVARCHAR (MAX) NULL,
    [Country]  NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

