﻿
create proc alter_table_Tbl_Student (

			@St_Name   nvarchar(50)
           ,@St_FName  nvarchar(50)
           ,@St_Address nvarchar(50)
           ,@St_Doc    nvarchar(50)
           ,@Reg_no    varchar(15)
 )
as
begin

INSERT INTO [dbo].[Tbl_Student]
           ([St_Name]
           ,[St_FName]
           ,[St_Address]
           ,[St_Doc]
           ,[Reg_no])
     VALUES
           (@St_Name  
           ,@St_FName   
           ,@St_Address 
           ,@St_Doc    
           ,@Reg_no   )
end
